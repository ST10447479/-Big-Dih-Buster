﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RecipeAPP
{
    class Program
    {
        static void Main(string[] args)
        {
            Program app = new Program();
            app.Recipe();
        }

        public void Recipe()
        {
            List<string> ingredients = new List<string>();

            //Taking input for ingredients
            Console.WriteLine("Enter the number of ingredients: ");
            int numOfIndgr = int.Parse(Console.ReadLine());

            for (int i = 0; i < numOfIndgr; i++)
            {
                Console.WriteLine("Enter the ingredient name:");
                string IndgrName = Console.ReadLine();

                Console.WriteLine("Please enter the unit of measurement:");
                string UnitOfMeasurement = Console.ReadLine();

                Console.WriteLine("Enter the ingredient quantity:");
                int IndgrQuant = int.Parse(Console.ReadLine());

                // Store ingredient information
                ingredients.Add(IndgrQuant + " " + UnitOfMeasurement + " of " + IndgrName);
            }

            //Taking input for steps
            Console.WriteLine("\nEnter the number of steps for the recipe: ");
            int numOfsteps = int.Parse(Console.ReadLine());

            List<string> steps = new List<string>();

            for (int i = 0; i < numOfsteps; i++)
            {
                Console.WriteLine("Enter Step " + (i + 1) + ":");
                string CurrentStep = Console.ReadLine();
                steps.Add("Step " + (i + 1) + ": " + CurrentStep);
            }

            //Printing the full recipe 
            Console.WriteLine("\n================= RECIPE =================\n");

            Console.WriteLine("Ingredients: \n");
            foreach (string ingredient in ingredients)
            {
                Console.WriteLine(ingredient);
            }

            Console.WriteLine("\nSteps: \n");
            foreach (string step in steps)
            {
                Console.WriteLine(step);
            }

            Console.WriteLine("_____________________________________\n");

            // Exit prompt
            Console.WriteLine("\nPress Enter to exit...");
            // Wait for user input before exiting
            Console.ReadLine(); 
        }
    }
}
